from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_restful import Api, Resource

# int app
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
db = SQLAlchemy(app)
ma = Marshmallow(app)
api = Api(app)

# Create database
class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(50))

#Constructor
class PostSchema(ma.Schema):
    class Meta:
        fields = ("id", "title")
        model = Post

# GetAll data in database
class GetAll(Resource):
    def get(self):
        posts = Post.query.all()
        return posts_schema.dump(posts)
api.add_resource(GetAll, '/getAll')

#Create or Add
class Create(Resource):
    def post(self):
        new_post = Post(
            title = request.json['title'],
        )
        db.session.add(new_post)
        db.session.commit()
        return post_schema.dump(new_post)
api.add_resource(Create, '/add')

#Fetch individual (Get by id)
class GetID(Resource):
    def get(self, post_id):
        post = Post.query.get_or_404(post_id)
        return post_schema.dump(post)
api.add_resource(GetID, '/posts/<int:post_id>')

#Update an existing field with id
class Update(Resource):
    def post(self, post_id):
        post = Post.query.get_or_404(post_id)

        if 'title' in request.json:
            post.title = request.json['title']
        
        db.session.commit()
        return post_schema.dump(post)
api.add_resource(Update, '/update/<int:post_id>')

#Delete field with id
@app.route('/delete/<int:post_id>', methods=['Delete'])
def delete(post_id):
    post = Post.query.get_or_404(post_id)
    db.session.delete(post)
    db.session.commit()
    return "Deleted"

post_schema = PostSchema()
posts_schema = PostSchema(many=True)

@app.route('/', methods=['GET'])
def get():
    return jsonify({'msg':'Hello World'})
    
# run server
if __name__ == '__main__':
       app.run(debug=True)
